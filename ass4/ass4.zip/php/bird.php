<figure class="bird">
    <picture>
        <a href="./php/species.php?bird_id=<?php echo $bird_id?>">
            <img src="<?php echo $src?>" alt="<?php echo $alt?>" />
        </a>        
    </picture>
    <figcaption><?php echo $caption?></figcaption>
</figure>