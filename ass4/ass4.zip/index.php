<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
?>

<?php
if(file_exists('./xml/birds.xml')){
    $birds = simplexml_load_file(('./xml/birds.xml'));
}else{
    exit('Failed to open birds.xml');
}
?>


<!DOCTYPE html>
<html lang="en">
  <!-- page header -->
  <head>
    <!-- page meta data -->
    <meta charset="utf-8" />
    <meta name="description" content="New Zealand Native Bird Catalogue - Explore and learn about New Zealand native birds." />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>New Zealand Native Bird Catalogue - Explore and learn about New Zealand native birds.</title>
    <!-- link to external CSS file-->
    <link rel="stylesheet" href="./css/stylesheet.css" />
  </head>
  <!-- page body -->
  <body class="theme-light">
    
    <!-- main content -->
    <main id="app" class="home">
        <section class="hero">
            <video loop muted autoplay preload="auto">
                <source src="./assets/video/video.mp4" type="video/mp4">
            </video>
            <div id="hero-text" class="content-wrap">
                <h1>New Zealand <br/> Native Bird <br/> <span>Catalogue</span></h1>
                <p>Explore and learn about the native birds of New Zealand.</p>
                <form action="./php/catalogue.php" method="POST">
                    <input id="btn-catalogue" value="Go to Catalogue" type="submit"/>
                </form>
                
            </div>
            <div id="scroll-down">                
                <span>S</span>
                <span>c</span>
                <span>r</span>
                <span>o</span>
                <span>l</span>
                <span>l</span>
            </div>
        </section> 
        <section id="categories">
            <div class="content-wrap">  
                <section class="category">
              
                    <h3>Recently Viewed</h3>
                    <div class="category-items <?php ?>">   
                          
                    </div>
                </section>
                <section class="category">
                    <h3>Threatened species</h3>
                </section>
                <section class="category">
                    <h3>Land Birds</h3>
                    <?php 
                        $results = $birds->xpath("//bird[classification='Land']");        
                        $count = count($results);
                        $scroll = "";
                        if($count >=5){
                            $scroll = "scrollable";
                        }                    
                    ?>
                    <div class="category-items <?php echo $scroll?>">    
                        <?php                             
                            foreach ($results as $result) {
                                $caption = $result->english_name;
                                $bird_id = $result->bird_id;
                                $src = $result->image_220;
                                $alt = $result->alt;
                                $src = "./assets/images/$src";                           
                                include("php/bird.php");
                            }
                        ?>                          
                    </div>
                </section>
                <section class="category">
                    <h3>Flightless Land Birds</h3>
                    <?php 
                        $results = $birds->xpath("//bird[classification='Flightless']");        
                        $count = count($results);
                        $scroll = "";
                        if($count >=5){
                            $scroll = "scrollable";
                        }                    
                    ?>
                    <div class="category-items <?php echo $scroll?>">    
                        <?php                
                            foreach ($results as $result) {
                                $caption = $result->english_name;
                                $bird_id = $result->bird_id;
                                $src = $result->image_220;
                                $alt = $result->alt;
                                $src = "./assets/images/$src";  
                                include("php/bird.php");
                            }
                        ?>                          
                    </div>
                </section>
                <section class="category">
                    <h3>Wetland Birds</h3>
                    <?php 
                        $results = $birds->xpath("//bird[classification='Wetland']");        
                        $count = count($results);
                        $scroll = "";
                        if($count >=5){
                            $scroll = "scrollable";
                        }                    
                    ?>
                    <div class="category-items <?php echo $scroll?>">    
                        <?php                
                            foreach ($results as $result) {
                                $caption = $result->english_name;
                                $bird_id = $result->bird_id;
                                $src = $result->image_220;
                                $alt = $result->alt;
                                $src = "./assets/images/$src";  
                                include("php/bird.php");
                            }
                        ?>                          
                    </div>
                </section>
                <section class="category">
                    <h3>Seabirds</h3>
                    <?php 
                        $results = $birds->xpath("//bird[classification='Seabird']");        
                        $count = count($results);
                        $scroll = "";
                        if($count >=5){
                            $scroll = "scrollable";
                        }                    
                    ?>
                    <div class="category-items <?php echo $scroll?>">    
                        <?php                
                            foreach ($results as $result) {
                                $caption = $result->english_name;
                                $bird_id = $result->bird_id;
                                $src = $result->image_220;
                                $alt = $result->alt;
                                $src = "./assets/images/$src";  
                                include("php/bird.php");
                            }
                        ?>                          
                    </div>
                </section>
                <section class="category">
                    <h3>Extinct Birds</h3>
                </section>
            </div>            
        </section>  
        <?php include("html/Footer.html")?>       
    </main>
  </body>
</html>

<!-- link to external Javascript file-->
<script src="./js/main.js" ></script>