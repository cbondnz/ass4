// window.addEventListener("pageshow", (event) => {
//   var xmlhttp = new XMLHttpRequest();
//   xmlhttp.onreadystatechange = function () {
//     if (this.readyState == 4 && this.status == 200) {
//       document.getElementById("recent-result").innerHTML = this.responseText;
//       console.log(document.getElementById("recent-result"));
//     }
//   };
//   xmlhttp.open("GET", "./process_cookie.php", true);
//   xmlhttp.send();
// });

if (!!window.performance && window.performance.navigation.type == 2) {
  console.log("test");
  window.location.reload();
}

// function AjaxCallWithPromise() {
//   return new Promise(function (resolve, reject) {
//     const objXMLHttpRequest = new XMLHttpRequest();

//     objXMLHttpRequest.onreadystatechange = function () {
//       if (objXMLHttpRequest.readyState === 4) {
//         if (objXMLHttpRequest.status == 200) {
//           resolve(objXMLHttpRequest.responseText);
//         } else {
//           reject("Error Code: " + objXMLHttpRequest.status + " Error Message: " + objXMLHttpRequest.statusText);
//         }
//       }
//     };

//     objXMLHttpRequest.open("GET", "request_ajax_data.php");
//     objXMLHttpRequest.send();
//   });
// }

// AjaxCallWithPromise().then(
//   (data) => {
//     console.log("Success Response: " + data);
//   },
//   (error) => {
//     console.log(error);
//   }
// );
